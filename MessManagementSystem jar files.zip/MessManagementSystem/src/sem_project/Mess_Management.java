package sem_project;


public class Mess_Management{

	public static void main(String[] args) {
        Admin_Login loginPage = new Admin_Login();
        loginPage.setVisible(true);
        
    }
}

