package sem_project;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

// Class to handle Excel file operations
class ExcelFileHandler {
    private static final String FILE_PATH = "D:\\MessAttendance.xlsx";

    public boolean updateMessUnits(int messNo, int units) {
        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            boolean found = false;

            for (Row row : sheet) {
                Cell messNoCell = row.getCell(0);
                if (messNoCell != null && messNoCell.getCellType() == CellType.NUMERIC &&
                        (int) messNoCell.getNumericCellValue() == messNo) {
                    found = true;

                    Cell messUnitsCell = row.getCell(2, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    double existingUnits = messUnitsCell.getCellType() == CellType.NUMERIC ? messUnitsCell.getNumericCellValue() : 0;
                    double newUnits = existingUnits + units;
                    messUnitsCell.setCellValue(newUnits);

                    Cell totalBillCell = row.getCell(3, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    totalBillCell.setCellValue(newUnits * 0.91);

                    break;
                }
            }

            if (found) {
                try (FileOutputStream fos = new FileOutputStream(FILE_PATH)) {
                    workbook.write(fos);
                }
            }

            return found;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}

// Class to handle button actions
class ActionButtonHandler {
    private ExcelFileHandler excelFileHandler;

    public ActionButtonHandler() {
        excelFileHandler = new ExcelFileHandler();
    }

    public ActionListener createSetUnitsButtonListener(JTextField unitsField, JLabel unitsDisplayLabel, JButton enterUnitsButton) {
        return e -> {
            String inputUnits = unitsField.getText().trim();
            if (inputUnits.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter the number of units.");
                return;
            }
            unitsDisplayLabel.setText("Current Meal Units: " + inputUnits);
            unitsField.setEnabled(false);
            enterUnitsButton.setEnabled(false);
        };
    }

    public ActionListener createSubmitButtonListener(JTextField messNumberField, JTextField unitsField) {
        return e -> {
            String inputMessNo = messNumberField.getText().trim();
            if (inputMessNo.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid mess number.");
                return;
            }

            int messNo;
            int currentUnits;
            try {
                messNo = Integer.parseInt(inputMessNo);
                currentUnits = Integer.parseInt(unitsField.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid format for mess number or units.");
                return;
            }

            boolean updated = excelFileHandler.updateMessUnits(messNo, currentUnits);
            if (!updated) {
                JOptionPane.showMessageDialog(null, "Mess number not found.");
            }
            messNumberField.setText(""); // Clear input after submission
        };
    }

    public ActionListener createBackButtonListener(JFrame currentFrame) {
        return e -> {
            HomePage homepage = new HomePage();
            homepage.setVisible(true);
            currentFrame.dispose();
        };
    }

    public ActionListener createCloseButtonListener(JFrame currentFrame) {
        return e -> currentFrame.dispose();
    }
}

// Main class for the Attendance Page
public class AttendancePage extends JFrame {

    private ActionButtonHandler actionButtonHandler;

    public AttendancePage() {
        actionButtonHandler = new ActionButtonHandler();

        // Step 1: Create the main frame
        setTitle("Attendance Page");
        setSize(800, 600); // Initial size
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Full-screen mode
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout()); // Main layout

        // Display current date at the top right
        String currentDate = new SimpleDateFormat("EEEE, MMMM dd, yyyy").format(new Date());
        JLabel dateLabel = new JLabel(currentDate, SwingConstants.RIGHT);
        dateLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        dateLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add the date label to the frame
        add(dateLabel, BorderLayout.NORTH);

        // Center panel for inputs
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.anchor = GridBagConstraints.CENTER;

        // Title label
        JLabel titleLabel = new JLabel("Mess Attendance System");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 36));

        // Instructional label
        JLabel instructionLabel = new JLabel("Enter the number of units for the current meal:");
        instructionLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));

        // Input field for units
        JTextField unitsField = new JTextField(10);
        unitsField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        unitsField.setHorizontalAlignment(JTextField.CENTER);

        JButton enterUnitsButton = new JButton("Set Units");
        enterUnitsButton.setFont(new Font("SansSerif", Font.PLAIN, 16));

        // Label to show the current units set
        JLabel unitsDisplayLabel = new JLabel("Current Meal Units: 0");
        unitsDisplayLabel.setFont(new Font("SansSerif", Font.PLAIN, 20));

        // Input field for mess number
        JLabel messNumberLabel = new JLabel("Enter the Mess Number:");
        messNumberLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));

        JTextField messNumberField = new JTextField(10);
        messNumberField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        messNumberField.setHorizontalAlignment(JTextField.CENTER);

        JButton submitButton = new JButton("Submit Mess Number");
        submitButton.setFont(new Font("SansSerif", Font.PLAIN, 16));

        // Add components to the center panel with alignment
        centerPanel.add(titleLabel, gbc);
        centerPanel.add(instructionLabel, gbc);
        centerPanel.add(unitsField, gbc);
        centerPanel.add(enterUnitsButton, gbc);
        centerPanel.add(unitsDisplayLabel, gbc);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)), gbc); // Spacer
        centerPanel.add(messNumberLabel, gbc);
        centerPanel.add(messNumberField, gbc);
        centerPanel.add(submitButton, gbc);

        // Bottom panel for "Close" and "Back" buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        bottomPanel.add(backButton);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        bottomPanel.add(closeButton);

        // Add center panel and bottom panel to the frame
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Event listener for the "Set Units" button
        enterUnitsButton.addActionListener(actionButtonHandler.createSetUnitsButtonListener(unitsField, unitsDisplayLabel, enterUnitsButton));

        // Event listener for the "Submit Mess Number" button
        submitButton.addActionListener(actionButtonHandler.createSubmitButtonListener(messNumberField, unitsField));

        // Event listener for the "Back" button
        backButton.addActionListener(actionButtonHandler.createBackButtonListener(this));

        // Event listener for the "Close" button
        closeButton.addActionListener(actionButtonHandler.createCloseButtonListener(this));

        // Make the frame visible
        setVisible(true);
    }

    public static void main(String[] args) {
        new AttendancePage();
    }
}
