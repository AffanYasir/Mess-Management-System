package sem_project;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BillGenerator extends JFrame{

    private String sourceFilePath;
    private String destinationFilePath;

    // Constructor to initialize file paths
    public BillGenerator(String sourceFilePath, String destinationFilePath) {
        this.sourceFilePath = sourceFilePath;
        this.destinationFilePath = destinationFilePath;
    }

    // Method to copy the Excel file
    public void export() {
        try {
            // Open the source Excel file
            FileInputStream fileInputStream = new FileInputStream(sourceFilePath);
            Workbook workbook = new XSSFWorkbook(fileInputStream);

            // Save a copy to the destination file
            FileOutputStream fileOutputStream = new FileOutputStream(destinationFilePath);
            workbook.write(fileOutputStream);

            // Close resources
            fileInputStream.close();
            fileOutputStream.close();
            workbook.close();

            JOptionPane.showMessageDialog(this, "Bill generated successfully and saved to: " + destinationFilePath);
        } catch (IOException e) {
        	JOptionPane.showMessageDialog(this,"Error while generating the bill recheck your excel file: " + e.getMessage());
        }
    }
}
