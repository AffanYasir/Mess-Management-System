package sem_project;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

class AuthenticationService {
    public boolean authenticate(String username, String password) {
        // Placeholder for actual authentication (e.g., database or configuration file)
        return "admin@jbh".equals(username) && "jbh123".equals(password);
    }
}

public class Admin_Login extends JFrame {
    private JTextField userTextField;
    private JPasswordField passwordField;

    public Admin_Login() {
        setTitle("Mess Management System - Admin Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600); // Exact size for desktop view
        setLocationRelativeTo(null); // Center window on the screen

        // Main panel setup with background image
        BackgroundPanel mainPanel = new BackgroundPanel("D:\\IMG_1669.jpg");
        mainPanel.setLayout(new BorderLayout());

        // Title Section (Transparent Panel)
        JPanel titlePanel = createTitlePanel();
        titlePanel.setOpaque(false); // Ensure transparency
        mainPanel.add(titlePanel, BorderLayout.NORTH);

        // Form Section (Transparent Panel)
        JPanel formPanel = createFormPanel();
        formPanel.setOpaque(false); // Ensure transparency
        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Add the main panel to the frame
        add(mainPanel);
    }

    private JPanel createTitlePanel() {
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 20));
        titlePanel.setOpaque(false); // Transparent background for title panel
        titlePanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10)); // Padding to match exact alignment

        JLabel mainTitle = new JLabel("Mess Management System");
        mainTitle.setFont(new Font("SansSerif", Font.BOLD, 36));
        mainTitle.setForeground(Color.WHITE);

        ImageIcon logo = new ImageIcon("C:\\Users\\AFFANYASIR\\OneDrive - University of Engineering and Technology Taxila\\Pictures\\1.png");
        Image scaledImage = logo.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH); // Exact size for the logo
        JLabel logoLabel = new JLabel(new ImageIcon(scaledImage));

        titlePanel.add(logoLabel);
        titlePanel.add(mainTitle);

        return titlePanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false); // Ensure transparent background

        // Set border for the form panel (to give it some padding)
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 40, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15); // Spacing between components
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        // Form Title
        JLabel loginTitle = new JLabel("Admin Login");
        loginTitle.setFont(new Font("SansSerif", Font.BOLD, 28));
        loginTitle.setForeground(Color.WHITE);
        gbc.gridy = 0;
        formPanel.add(loginTitle, gbc);

        // Username Label and Text Field
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        userLabel.setForeground(Color.WHITE);
        gbc.gridy = 1;
        formPanel.add(userLabel, gbc);

        userTextField = new JTextField(15); // Exact size of the input fields
        userTextField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        gbc.gridy = 2;
        formPanel.add(userTextField, gbc);

        // Password Label and Text Field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        passwordLabel.setForeground(Color.WHITE);
        gbc.gridy = 3;
        formPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(15); // Exact size of the input fields
        passwordField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        gbc.gridy = 4;
        formPanel.add(passwordField, gbc);

        // Login Button
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        loginButton.setBackground(new Color(100, 150, 200));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBorder(new RoundedBorder(15));
        loginButton.setFocusPainted(false);
        gbc.gridy = 5;
        formPanel.add(loginButton, gbc);

        // Attach login action
        loginButton.addActionListener(this::handleLogin);

        // Developers' Name Section
        JLabel developersLabel = new JLabel("Developed by: Affan Yasir & Aimen Rauf");
        developersLabel.setFont(new Font("SansSerif", Font.ITALIC, 14));
        developersLabel.setForeground(Color.WHITE);
        gbc.gridy = 6;
        formPanel.add(developersLabel, gbc);

        return formPanel;
    }

    private void handleLogin(ActionEvent e) {
        String username = userTextField.getText();
        String password = new String(passwordField.getPassword());

        AuthenticationService authService = new AuthenticationService();
        if (authService.authenticate(username, password)) {
            HomePage homepage = new HomePage();
            homepage.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static class RoundedPanel extends JPanel {
        private int radius;
        private Color backgroundColor;

        public RoundedPanel(int radius, Color backgroundColor) {
            this.radius = radius;
            this.backgroundColor = backgroundColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(backgroundColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
        }
    }

    private static class RoundedBorder extends AbstractBorder {
        private int radius;

        public RoundedBorder(int radius) {
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.GRAY);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }

    private static class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            backgroundImage = new ImageIcon(imagePath).getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this); // Cover the entire background
            g2.setColor(new Color(0, 0, 0, 150)); // Tint overlay applied uniformly
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Admin_Login login = new Admin_Login();
            login.setVisible(true);
        });
    }
}
