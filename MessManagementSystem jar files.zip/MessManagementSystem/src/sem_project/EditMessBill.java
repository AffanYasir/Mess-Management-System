package sem_project;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.*;

// Interface for Excel file operations
interface ExcelFileHandle {
    boolean updateMessUnits(int messNo, double unitsChange) throws IOException;

    void clearMessData() throws IOException;
}

// Class for Excel file handling
class ExcelHandler implements ExcelFileHandle {
    private static final String FILE_PATH = "D:\\MessAttendance.xlsx";

    @Override
    public boolean updateMessUnits(int messNo, double unitsChange) throws IOException {
        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            boolean found = false;

            for (Row row : sheet) {
                Cell messNoCell = row.getCell(0);
                if (messNoCell != null && messNoCell.getCellType() == CellType.NUMERIC &&
                        (int) messNoCell.getNumericCellValue() == messNo) {
                    found = true;

                    Cell messUnitsCell = row.getCell(2, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    double currentUnits = messUnitsCell.getCellType() == CellType.NUMERIC ? messUnitsCell.getNumericCellValue() : 0;
                    double newUnits = currentUnits + unitsChange;
                    messUnitsCell.setCellValue(newUnits);

                    Cell totalBillCell = row.getCell(3, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    totalBillCell.setCellValue(newUnits * 0.91);

                    break;
                }
            }

            if (found) {
                try (FileOutputStream fos = new FileOutputStream(FILE_PATH)) {
                    workbook.write(fos);
                }
            }

            return found;
        }
    }

    @Override
    public void clearMessData() throws IOException {
        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                // Skip the header row (row index 0)
                if (row.getRowNum() == 0) {
                    continue;
                }

                Cell messUnitsCell = row.getCell(2, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                Cell totalBillCell = row.getCell(3, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

                messUnitsCell.setCellValue(0);
                totalBillCell.setCellValue(0);
            }

            try (FileOutputStream fos = new FileOutputStream(FILE_PATH)) {
                workbook.write(fos);
            }
        }
    }

}

// Main UI class
public class EditMessBill extends JFrame {
    private final ExcelFileHandle fileHandler;

    public EditMessBill(ExcelFileHandle fileHandler) {
        this.fileHandler = fileHandler;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Edit Mess Bill");
        setSize(800, 600);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel centerPanel = createCenterPanel();
        JPanel bottomPanel = createBottomPanel();

        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel createCenterPanel() {
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel titleLabel = new JLabel("Edit Mess Bill");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 36));

        JLabel messNoLabel = new JLabel("Enter the Mess Number:");
        messNoLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));

        JTextField messNoField = new JTextField(10);
        messNoField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        messNoField.setHorizontalAlignment(JTextField.CENTER);

        JLabel unitsLabel = new JLabel("Enter Units to Add/Subtract:");
        unitsLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));

        JTextField unitsField = new JTextField(10);
        unitsField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        unitsField.setHorizontalAlignment(JTextField.CENTER);

        JButton addButton = createAddButton(messNoField, unitsField);
        JButton subtractButton = createSubtractButton(messNoField, unitsField);
        JButton clearButton = createClearButton();

        centerPanel.add(titleLabel, gbc);
        centerPanel.add(messNoLabel, gbc);
        centerPanel.add(messNoField, gbc);
        centerPanel.add(unitsLabel, gbc);
        centerPanel.add(unitsField, gbc);
        centerPanel.add(addButton, gbc);
        centerPanel.add(subtractButton, gbc);
        centerPanel.add(clearButton, gbc);

        return centerPanel;
    }

    private JPanel createBottomPanel() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        backButton.addActionListener(e -> {
            new HomePage().setVisible(true);
            dispose();
        });

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        closeButton.addActionListener(e -> dispose());

        bottomPanel.add(backButton);
        bottomPanel.add(closeButton);

        return bottomPanel;
    }

    private JButton createAddButton(JTextField messNoField, JTextField unitsField) {
        JButton addButton = new JButton("Add Units");
        addButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        addButton.addActionListener(e -> handleUnitsUpdate(messNoField, unitsField, true));
        return addButton;
    }

    private JButton createSubtractButton(JTextField messNoField, JTextField unitsField) {
        JButton subtractButton = new JButton("Subtract Units");
        subtractButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        subtractButton.addActionListener(e -> handleUnitsUpdate(messNoField, unitsField, false));
        return subtractButton;
    }

    private JButton createClearButton() {
        JButton clearButton = new JButton("Clear Data");
        clearButton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        clearButton.setBackground(Color.RED);
        clearButton.setForeground(Color.WHITE);
        clearButton.addActionListener(e -> {
            try {
                fileHandler.clearMessData();
                JOptionPane.showMessageDialog(this, "Data cleared successfully!");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error clearing data: " + ex.getMessage());
            }
        });
        return clearButton;
    }

    private void handleUnitsUpdate(JTextField messNoField, JTextField unitsField, boolean isAddition) {
        String messNoStr = messNoField.getText().trim();
        String unitsStr = unitsField.getText().trim();

        if (messNoStr.isEmpty() || unitsStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        try {
            int messNo = Integer.parseInt(messNoStr);
            double unitsChange = Double.parseDouble(unitsStr);
            if (!isAddition) unitsChange = -unitsChange;

            boolean success = fileHandler.updateMessUnits(messNo, unitsChange);

            JOptionPane.showMessageDialog(this, success ? "Mess bill updated successfully!" : "Mess number not found.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input format.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error updating Excel file: " + ex.getMessage());
        }

        messNoField.setText("");
        unitsField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EditMessBill(new ExcelHandler()));
    }
}
