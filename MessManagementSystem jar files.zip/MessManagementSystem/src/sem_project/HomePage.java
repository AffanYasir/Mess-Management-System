package sem_project;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.AbstractBorder;


class RoundedBorder extends AbstractBorder {
    private int radius;

    public RoundedBorder(int radius) {
        this.radius = radius;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(c.getForeground());
        g2d.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(10, 10, 10, 10);
    }

    @Override
    public Insets getBorderInsets(Component c, Insets insets) {
        insets.set(10, 10, 10, 10);
        return insets;
    }
}

public class HomePage extends JFrame {

    public HomePage() {
        // Main frame
        setTitle("Admin Home Page");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Full screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Background color of the frame and the content pane 
        getContentPane().setBackground(Color.WHITE);

        // Main panel for tiles with a white background
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 3, 20, 20)); // 2 rows, 3 columns, with spacing
        panel.setBackground(Color.WHITE); // White background for the panel
        panel.setBorder(BorderFactory.createEmptyBorder(50, 300, 50, 300)); // Padding to center tiles

        // Welcome label
        JLabel welcomeLabel = new JLabel("Welcome!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("SansSerif", Font.BOLD, 36));
        welcomeLabel.setForeground(Color.BLACK);

        // Home page label
        JLabel homePageLabel = new JLabel("Home Page", SwingConstants.CENTER);
        homePageLabel.setFont(new Font("SansSerif", Font.BOLD, 30));
        homePageLabel.setForeground(Color.BLACK);

        // Buttons for each function with a similar design
        JButton attendanceButton = createStyledButton("Attendance");
        JButton billGenerateButton = createStyledButton("Bill Generate");
        JButton studentDetailsButton = createStyledButton("Student Details");
        JButton editMessBillButton = createStyledButton("Edit Mess Bill");
        JButton defaulterListButton = createStyledButton("Defaulter List");
        JButton exitButton = createStyledButton("Exit");

        // Action listeners for each button
        attendanceButton.addActionListener(e -> showAttendanceTab());
        billGenerateButton.addActionListener(e -> generateBill());
        studentDetailsButton.addActionListener(e -> viewStudentDetails());
        editMessBillButton.addActionListener(e -> editMessBill());
        defaulterListButton.addActionListener(e -> showDefaulterList());
        exitButton.addActionListener(e -> System.exit(0));

        // Add buttons to the panel
        panel.add(attendanceButton);
        panel.add(billGenerateButton);
        panel.add(studentDetailsButton);
        panel.add(editMessBillButton);
        panel.add(defaulterListButton);
        panel.add(exitButton);

        // To add the labels and panel to the frame
        add(welcomeLabel, BorderLayout.NORTH);
        add(homePageLabel, BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);

        // Make the frame visible
        setVisible(true);
    }

    // Method to create a styled button as a square tile with light blue background and rounded corners
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(173, 216, 230)); // Light blue color for buttons (tiles)
        button.setForeground(Color.BLACK);
        button.setFont(new Font("SansSerif", Font.PLAIN, 18)); // Consistent font
        //button.setFocusPainted(false);
        button.setBorder(new RoundedBorder(30)); // Set rounded border with 30px radius
        button.setPreferredSize(new Dimension(150, 150)); // width and height for a square shape
        return button;
    }

    // Placeholder methods for each tab function
    private void showAttendanceTab() {
        AttendancePage attendancepage = new AttendancePage();
        attendancepage.setVisible(true);
    }

    private void generateBill() {
        String sourceFilePath = "D:\\MessAttendance.xlsx";
        String destinationFilePath = "D:\\Mess Bill.xlsx";

        // Create an instance of BillGenerator
        BillGenerator exporter = new BillGenerator(sourceFilePath, destinationFilePath);
        exporter.export();
    }

    private void viewStudentDetails() {
        String filePath = "D:\\MessAttendance.xlsx";

        // Create an instance of StudentDetailsViewer
        StudentDetailsViewer viewer = new StudentDetailsViewer(filePath);

        // Call the displayDetails method to show the GUI
        viewer.displayDetails();
    }

    private void editMessBill() {
        ExcelFileHandle fileHandler = new ExcelHandler(); // Create an instance of the implementing class
        new EditMessBill(fileHandler).setVisible(true);  // Pass the handler to EditMessBill
        dispose(); // Close the current page
    }



    private void showDefaulterList() {
        // Launch the Defaulter Input Page
        SwingUtilities.invokeLater(() -> new DefaulterListInputPage());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HomePage::new);
    }
}
