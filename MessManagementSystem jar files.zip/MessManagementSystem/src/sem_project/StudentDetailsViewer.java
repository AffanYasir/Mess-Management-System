package sem_project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class StudentDetailsViewer {

	private String filePath;

    // Constructor to initialize file path
    public StudentDetailsViewer(String filePath) {
        this.filePath = filePath;
    }

    // Method to display student details in a GUI
    public void displayDetails() {
        try {
            // Load the Excel file
            FileInputStream fileInputStream = new FileInputStream(filePath);
            Workbook workbook = new XSSFWorkbook(fileInputStream);
            Sheet sheet = workbook.getSheetAt(0); // Access the first sheet

            // Prepare data for JTable
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.addColumn("Mess No.");
            tableModel.addColumn("Name");
            tableModel.addColumn("Mess Units");
            tableModel.addColumn("Total Bill");

            // Iterate through rows starting from the second row (skipping headers)
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);

                if (row != null) {
                    // Get Mess No. (Numeric)
                    int messNo = (int) row.getCell(0).getNumericCellValue(); // Column A

                    // Get Name (String)
                    Cell nameCell = row.getCell(1); // Column B
                    String name = "";
                    if (nameCell != null) {
                        if (nameCell.getCellType() == CellType.STRING) {
                            name = nameCell.getStringCellValue();
                        } else if (nameCell.getCellType() == CellType.NUMERIC) {
                            name = String.valueOf((int) nameCell.getNumericCellValue());
                        }
                    }

                    // Get Mess Units (Numeric, default to 0 if cell is null)
                    Cell messUnitsCell = row.getCell(2); // Column C
                    double messUnits = messUnitsCell != null && messUnitsCell.getCellType() == CellType.NUMERIC
                            ? messUnitsCell.getNumericCellValue()
                            : 0;

                    // Get Total Bill (Numeric, default to 0 if cell is null)
                    Cell totalBillCell = row.getCell(3); // Column D
                    double totalBill = totalBillCell != null && totalBillCell.getCellType() == CellType.NUMERIC
                            ? totalBillCell.getNumericCellValue()
                            : 0;

                    // Add row to table model
                    tableModel.addRow(new Object[]{messNo, name, messUnits, totalBill});
                }
            }

            // Create JTable and set its model
            JTable table = new JTable(tableModel);

            // Set table properties
            table.setRowHeight(30);
            table.setFont(new Font("Arial", Font.PLAIN, 14));
            table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 16));
            table.getTableHeader().setBackground(Color.LIGHT_GRAY);
            table.setBackground(new Color(240, 248, 255)); // Light blue background

            // Wrap table in a JScrollPane
            JScrollPane scrollPane = new JScrollPane(table);

            // Create and configure the JFrame
            JFrame frame = new JFrame("Student Details");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(600, 400);
            frame.setLayout(new BorderLayout());
            frame.getContentPane().setBackground(new Color(240, 248, 255)); // Light blue background

            // Add components to the frame
            JLabel titleLabel = new JLabel("Student Details", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
            titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

            frame.add(titleLabel, BorderLayout.NORTH);
            frame.add(scrollPane, BorderLayout.CENTER);

            // Make the frame visible
            frame.setVisible(true);

            // Close resources
            fileInputStream.close();
            workbook.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error while reading student details: " + e.getMessage(),
                                          "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
