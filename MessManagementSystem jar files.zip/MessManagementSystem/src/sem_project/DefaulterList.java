package sem_project;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.Font;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Data Class: Represents a defaulter record
class DefaulterRecord {
    private final String messNumber;
    private final String name;
    private final double pendingAmount;
    private final String month;

    public DefaulterRecord(String messNumber, String name, double pendingAmount, String month) {
        this.messNumber = messNumber;
        this.name = name;
        this.pendingAmount = pendingAmount;
        this.month = month;
    }

    public String getMessNumber() {
        return messNumber;
    }

    public String getName() {
        return name;
    }

    public double getPendingAmount() {
        return pendingAmount;
    }

    public String getMonth() {
        return month;
    }
}

// File Manager Class: Handles file operations
class DefaulterFileManager {
    private static final String FILE_PATH = "D:\\Defaulter List.xlsx";

    public static void ensureFileExists() throws IOException {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            try (Workbook workbook = new XSSFWorkbook();
                 FileOutputStream fos = new FileOutputStream(file)) {
                Sheet sheet = workbook.createSheet("Defaulters");
                Row headerRow = sheet.createRow(0);
                headerRow.createCell(0).setCellValue("Mess Number");
                headerRow.createCell(1).setCellValue("Student Name");
                headerRow.createCell(2).setCellValue("Pending Amount");
                headerRow.createCell(3).setCellValue("Month");
                workbook.write(fos);
            }
        }
    }

    public static void addRecord(DefaulterRecord record) throws IOException {
        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            int lastRow = sheet.getLastRowNum();
            Row newRow = sheet.createRow(lastRow + 1);

            newRow.createCell(0).setCellValue(record.getMessNumber());
            newRow.createCell(1).setCellValue(record.getName());
            newRow.createCell(2).setCellValue(record.getPendingAmount());
            newRow.createCell(3).setCellValue(record.getMonth());

            try (FileOutputStream fos = new FileOutputStream(FILE_PATH)) {
                workbook.write(fos);
            }
        }
    }

    public static List<DefaulterRecord> loadRecords() throws IOException {
        List<DefaulterRecord> records = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header
                String messNumber = getCellValueAsString(row.getCell(0));
                String name = getCellValueAsString(row.getCell(1));
                double pendingAmount = Double.parseDouble(getCellValueAsString(row.getCell(2)));
                String month = getCellValueAsString(row.getCell(3));
                records.add(new DefaulterRecord(messNumber, name, pendingAmount, month));
            }
        }
        return records;
    }

    private static String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }
}

// Input Page: Handles data entry
class DefaulterListInputPage extends JFrame {
    public DefaulterListInputPage() {
        setTitle("Create Defaulter List");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());

        try {
            DefaulterFileManager.ensureFileExists();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error creating file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Create Defaulter List", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        JTextField messNumberField = new JTextField(15);
        JTextField nameField = new JTextField(15);
        JTextField pendingAmountField = new JTextField(15);
        JTextField monthField = new JTextField(15);
        JButton submitButton = new JButton("Submit");
        JButton previewButton = new JButton("Preview Defaulter List");

        add(titleLabel, gbc);
        add(new JLabel("Mess Number:"), gbc);
        add(messNumberField, gbc);
        add(new JLabel("Student Name:"), gbc);
        add(nameField, gbc);
        add(new JLabel("Pending Amount:"), gbc);
        add(pendingAmountField, gbc);
        add(new JLabel("Month:"), gbc);
        add(monthField, gbc);
        add(submitButton, gbc);
        add(previewButton, gbc);

        submitButton.addActionListener(e -> {
            try {
                DefaulterFileManager.addRecord(new DefaulterRecord(
                        messNumberField.getText().trim(),
                        nameField.getText().trim(),
                        Double.parseDouble(pendingAmountField.getText().trim()),
                        monthField.getText().trim()));
                JOptionPane.showMessageDialog(this, "Details added successfully.");
                messNumberField.setText("");
                nameField.setText("");
                pendingAmountField.setText("");
                monthField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        previewButton.addActionListener(e -> new DefaulterListPreviewPage());

        setVisible(true);
    }
}

// Preview Page: Displays records
class DefaulterListPreviewPage extends JFrame {
    public DefaulterListPreviewPage() {
        setTitle("Defaulter List Preview");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel titleLabel = new JLabel("Defaulter List", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        JTable table = new JTable(new DefaultTableModel(new Object[]{"Mess Number", "Student Name", "Pending Amount", "Month"}, 0));
        add(new JScrollPane(table), BorderLayout.CENTER);

        try {
            for (DefaulterRecord record : DefaulterFileManager.loadRecords()) {
                ((DefaultTableModel) table.getModel()).addRow(new Object[]{
                        record.getMessNumber(), record.getName(), record.getPendingAmount(), record.getMonth()});
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> dispose());
        add(backButton, BorderLayout.SOUTH);

        setVisible(true);
    }
}

// Main Class
public class DefaulterList {
    public static void main(String[] args) {
        new DefaulterListInputPage();
    }
}
